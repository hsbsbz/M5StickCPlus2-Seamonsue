
#include "Point.h"

namespace hsbs {

Point::Point(float x, float y) {
  this->x = x;
  this->y = y;
}

} // namespace hsbs
